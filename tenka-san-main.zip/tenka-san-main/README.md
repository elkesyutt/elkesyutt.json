# Hello There, Yuukey-7eppeli Is Here
<p align='center'>
   <img src="https://files.catbox.moe/rhm9rt.webp" width="250"/>
</p>
<p align="center">
    <a href="https://sociabuzz.com/yuukeyd7eppeli" target="_blank">Donasi Seikhlasnya Cik🥰<a>
</p>
   
---

## All About Me
```json
{
  "name": "Yuukey-7eppeli",
  "BirtDay": "25-02-2008",
  "Age": "17 Y'Old",
  "Hobbies": [
    "Sleep",
    "Make A Fvcking Code",
    "Sleep",
    "Make Somebody Happy"
  ],
  "Skills": [
    "StacksAndExperience": {
      "JavaScript": "70%",
      "HTML": "50%",
      "Python": "85%"
      "CSS": "0%"
    },
    "Sleep"
  ]
}
```

---
